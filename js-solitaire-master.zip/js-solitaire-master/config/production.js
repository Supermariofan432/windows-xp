module.exports = {
    inject: {
        CDN_URL: '',
        CONTENT_SECURITY_POLICY: 'bar'
    }
};
