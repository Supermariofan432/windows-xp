# JavaScript Solitaire Game

DEV env: `yarn && yarn start`

Production build: `yarn build`

![JavaScript Solitaire](https://raw.githubusercontent.com/uzi88/js-solitaire/master/screen-shot.png)

![JavaScript Solitaire Win](https://raw.githubusercontent.com/uzi88/js-solitaire/master/screen-shot-win.png)

Demo: http://radovanjanjic.com/js-solitaire/
