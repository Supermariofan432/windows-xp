minesweeper
===========
Clone of Microsoft's Minesweeper from Windows XP. An effort was made to duplicate every feature (excluding menus) as exactly as possible.

Demo: http://jonziebell.com/minesweeper
